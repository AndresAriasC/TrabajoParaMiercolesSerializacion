﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaBanco
{
    [Serializable]
    public class RegistroSerializable
    {
        private int isbn;
        private string titulo;
        private string autor;
        private int editorial;
        private int paginas;

        public RegistroSerializable() : this(0, "", "",0,0)
        {

        }

        public RegistroSerializable(int valorIsbn, string valorTitulo,
            string valorAutor, int valorEditorial, int valorPagina)
        {
            Isbn = valorIsbn;
            Titulo = valorTitulo;
            Autor = valorAutor;
            Editorial = valorEditorial;
            Paginas = valorPagina;
        }

        public int Isbn { get => isbn; set => isbn = value; }
        public string Titulo { get => titulo; set => titulo = value; }
        public string Autor { get => autor; set => autor = value; }
        public int Editorial { get => editorial; set => editorial = value; }
        public int Paginas { get => paginas; set => paginas = value; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BibliotecaBanco
{
    public partial class frmBancoUI : Form
    {
        protected int CuentaTextBox = 5;

        public enum IndicesTextBox
        {
            ISBN,
            TITULO,
            AUTOR,
            EDITORIAL,
            PAGINAS
        }

        public frmBancoUI()
        {
            InitializeComponent();
        }

        public void LimpiarTexBox()
        {
            for (int i = 0; i < Controls.Count; i++)
            {
                Control miControl = Controls[i];
                if (miControl is TextBox)
                    miControl.Text = "";
            }
        }

        public void SetValoresTexBox(string[] valores)
        {
            if (valores.Length != CuentaTextBox)
            {
                throw (new ArgumentException("Debe haber " +
                    (CuentaTextBox + 1) + " objetos string en el arreglo"));
            }
            else
            {
                txtISBN.Text = valores[(int)IndicesTextBox.ISBN];
                txtTitulo.Text = valores[(int)IndicesTextBox.TITULO];
                txtAutor.Text = valores[(int)IndicesTextBox.AUTOR];
                txtEditorial.Text = valores[(int)IndicesTextBox.EDITORIAL];
                txtPaginas.Text = valores[(int)IndicesTextBox.PAGINAS];
            }
        }

        public string[] GetValoresTextBox()
        {
            string[] valores = new string[CuentaTextBox];

            valores[(int)IndicesTextBox.ISBN] = txtISBN.Text;
            valores[(int)IndicesTextBox.TITULO] = txtTitulo.Text;
            valores[(int)IndicesTextBox.AUTOR] = txtAutor.Text;
            valores[(int)IndicesTextBox.EDITORIAL] = txtEditorial.Text;
            valores[(int)IndicesTextBox.PAGINAS] = txtPaginas.Text;

            return valores;
        }
    }
}

﻿namespace CrearArchivo
{
    partial class frmCrearArchivo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnGuardar = new Button();
            btnIntroducir = new Button();
            btnSalir = new Button();
            btnSerializar = new Button();
            btnDeserializar = new Button();
            SuspendLayout();
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(43, 259);
            btnGuardar.Margin = new Padding(3, 4, 3, 4);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(153, 31);
            btnGuardar.TabIndex = 8;
            btnGuardar.Text = "Guardar como";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnIntroducir
            // 
            btnIntroducir.Enabled = false;
            btnIntroducir.Location = new Point(275, 261);
            btnIntroducir.Margin = new Padding(3, 4, 3, 4);
            btnIntroducir.Name = "btnIntroducir";
            btnIntroducir.Size = new Size(100, 28);
            btnIntroducir.TabIndex = 9;
            btnIntroducir.Text = "Introducir";
            btnIntroducir.UseVisualStyleBackColor = true;
            btnIntroducir.Click += btnIntroducir_Click;
            // 
            // btnSalir
            // 
            btnSalir.Location = new Point(444, 309);
            btnSalir.Margin = new Padding(3, 4, 3, 4);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(158, 31);
            btnSalir.TabIndex = 10;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // btnSerializar
            // 
            btnSerializar.Location = new Point(381, 259);
            btnSerializar.Name = "btnSerializar";
            btnSerializar.Size = new Size(105, 29);
            btnSerializar.TabIndex = 11;
            btnSerializar.Text = "Serializar";
            btnSerializar.UseVisualStyleBackColor = true;
            btnSerializar.Click += btnSerializar_Click;
            // 
            // btnDeserializar
            // 
            btnDeserializar.Location = new Point(492, 261);
            btnDeserializar.Name = "btnDeserializar";
            btnDeserializar.Size = new Size(110, 29);
            btnDeserializar.TabIndex = 12;
            btnDeserializar.Text = "Deserializar";
            btnDeserializar.UseVisualStyleBackColor = true;
            // 
            // frmCrearArchivo
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(658, 377);
            Controls.Add(btnDeserializar);
            Controls.Add(btnSerializar);
            Controls.Add(btnSalir);
            Controls.Add(btnIntroducir);
            Controls.Add(btnGuardar);
            Margin = new Padding(3, 5, 3, 5);
            Name = "frmCrearArchivo";
            Text = "Creación de ";
            Controls.SetChildIndex(btnGuardar, 0);
            Controls.SetChildIndex(btnIntroducir, 0);
            Controls.SetChildIndex(btnSalir, 0);
            Controls.SetChildIndex(btnSerializar, 0);
            Controls.SetChildIndex(btnDeserializar, 0);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnGuardar;
        private Button btnIntroducir;
        private Button btnSalir;
        private Button btnSerializar;
        private Button btnDeserializar;
    }
}
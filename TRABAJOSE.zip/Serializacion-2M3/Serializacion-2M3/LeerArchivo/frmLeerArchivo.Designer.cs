﻿namespace LeerArchivo
{
    partial class frmLeerArchivo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAbrir = new Button();
            btnSiguiente = new Button();
            SuspendLayout();
            // 
            // btnAbrir
            // 
            btnAbrir.Location = new Point(212, 261);
            btnAbrir.Margin = new Padding(3, 4, 3, 4);
            btnAbrir.Name = "btnAbrir";
            btnAbrir.Size = new Size(190, 31);
            btnAbrir.TabIndex = 8;
            btnAbrir.Text = "Abrir archivo";
            btnAbrir.UseVisualStyleBackColor = true;
            btnAbrir.Click += btnAbrir_Click;
            // 
            // btnSiguiente
            // 
            btnSiguiente.Enabled = false;
            btnSiguiente.Location = new Point(412, 261);
            btnSiguiente.Margin = new Padding(3, 4, 3, 4);
            btnSiguiente.Name = "btnSiguiente";
            btnSiguiente.Size = new Size(190, 31);
            btnSiguiente.TabIndex = 9;
            btnSiguiente.Text = "Siguiente registro";
            btnSiguiente.UseVisualStyleBackColor = true;
            btnSiguiente.Click += btnSiguiente_Click;
            // 
            // frmLeerArchivo
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(689, 357);
            Controls.Add(btnSiguiente);
            Controls.Add(btnAbrir);
            Margin = new Padding(3, 5, 3, 5);
            Name = "frmLeerArchivo";
            Text = "Leer un archivo";
            Controls.SetChildIndex(btnAbrir, 0);
            Controls.SetChildIndex(btnSiguiente, 0);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAbrir;
        private Button btnSiguiente;
    }
}